cv_spectral  --  Spectral-typeface edition of the CV (created 2026-09-20)

What it is
  Same wording as cv_xcharter/cv.tex as of 2026-09-19; only the typography
  and layout differ (Spectral instead of XCharter, name + affiliation left
  and contact block right, name in SemiBold 24pt, letterspaced small-caps section heads, SemiBold
  as the bold weight, 12pt with 1.03 leading, 0.6in side margins).
  cv.pdf                   = the redesign (left masthead, name SemiBold 24pt, Regular body)
  cv_name_light30.pdf      = same with the name in Light 30pt (\namesemiboldfalse)
  cv_centered_masthead.pdf = same file compiled with \centeredheadtrue
  cv_light.pdf             = compiled with \lightbodytrue (Light body, SemiBold accents)
  cv_light_medium.pdf      = Light body with Medium accents (the two *-SemiBold
                             lines in the Light branch changed to *-Medium)

Build
  XeLaTeX only:  latexmk -xelatex cv.tex
  Fonts are bundled (Spectral-*.ttf, the copies TeX Live ships in its
  `spectral` package, v2.001), so it compiles here and on Overleaf.
  Build in a scratch copy; keep aux/log files out of this Dropbox folder.

Toggles (preamble / top of body)
  \namesemiboldtrue / \namesemiboldfalse  name SemiBold 24pt or Light 30pt
  \lightbodyfalse / \lightbodytrue     Regular or Light body weight
  \centeredheadfalse / \centeredheadtrue  left or classic centred masthead

Making it an Overleaf project
  Overleaf does not turn folders added to Dropbox into projects. Upload
  ../cv_spectral_overleaf_upload.zip via New Project > Upload Project and
  name the project "CV Spectral" (not "cv_spectral"), so the Dropbox sync
  creates its own folder instead of colliding with this one.
